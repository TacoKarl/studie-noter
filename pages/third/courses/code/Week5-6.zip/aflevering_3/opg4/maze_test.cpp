#include "MazeSolver.h"

int main(){
  std::vector<std::vector<char>> maze = {{'X', 'X', 'X', 'X', 'X'},
                                         {'X', ' ', ' ', ' ', 'X'},
                                         {'X', ' ', 'X', ' ', 'X'},
                                         {'X', ' ', 'X', ' ', 'X'},
                                         {'X', 'E', 'X', 'X', 'X'}};

  MazeSolver solver(maze);

  if (solver.solveMaze(maze, 1, 1)) {
    std::cout << "Path to exit found!\nMaze size: " << maze.size() << std::endl;
  } else {
    std::cout << "No path to exit found.\nMaze size: " << maze.size()
              << std::endl;
  }
  // fejltest
  if (solver.solveMaze(maze, 0, 1)) {
    std::cout << "Path to exit found!\nMaze size: " << maze.size() << std::endl;
  } else {
    std::cout << "No path to exit found.\nMaze size: " << maze.size()
              << std::endl;
  }
}
