#pragma once
#include <iostream>
#include <vector>

class MazeSolver {
public:
  MazeSolver(std::vector<std::vector<char>> maze);
  void reset();

  bool solveMaze(std::vector<std::vector<char>> &maze, int row, int col);

private:
  std::vector<std::vector<bool>> visited; // To keep track of visited positions
};
