#include "array.h"
#include <iostream>

int main() {
  Array a(6);
  std::cout << "Inserting 0...5\n";
  for (int i = 0; i < 6; i++) {
    a.insert(i);
  }
  std::cout << "Contains 3? (1 for yes, 0 for no): " << a.contains(3)
            << std::endl;
  std::cout << "Contains 6? (1 for yes, 0 for no): " << a.contains(6)
            << std::endl;
  a.minMax();
  
  return 0;
}
