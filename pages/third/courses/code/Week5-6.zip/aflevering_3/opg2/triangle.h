#include <iostream>

void triangle(int m, int n);
