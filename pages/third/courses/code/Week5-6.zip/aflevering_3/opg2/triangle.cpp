#include "triangle.h"
#include <string>

void triangle(int m, int n) {

  // Building the string according to m
  std::string str = "";
  for (int i = 0; i < m; i++) {
    str += "*";
  }

  // Printing the string
  std::cout << str << std::endl;

  // If m == n --> top of triangle is reached. Print line again and return to draw buttom
  if (m == n) {
    std::cout << str << std::endl;
    return;
  }
  // Draw the next line
  triangle(m + 1, n);

  // Draw bottom part of triangle
  std::cout << str << std::endl;
}
