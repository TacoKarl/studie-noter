#include "triangle.h"

int main(){
  triangle(2, 5); 
}
