#pragma once
#include<vector>

using namespace std;


template <typename Comparable>
void selectionSort(vector<Comparable>& a) {
	
	for (auto i = 0; i < a.size()-1; i++)
	{
		for (auto j = i+1; j < a.size(); j++)
		{
			if (a[j]<a[i])
			{
				swap(a[i], a[j]);
			}
		}
		
	}
}
