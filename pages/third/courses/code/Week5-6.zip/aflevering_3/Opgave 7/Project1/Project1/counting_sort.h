#pragma once
#include<vector>
#include <algorithm>

using namespace std;


template <typename Comparable>
void countingSort(vector<Comparable>& a) {
	vector <int> temp;
	vector <int> temp1;
	auto max_element1 = max_element(a.begin(), a.end());
	temp.resize(*max_element1+1);
	temp1.resize(a.size());
	
	for (auto i = 0; i < a.size(); i++)
	{
		temp[a[i]]++;
	}

	for (auto i = 0; i < a.size(); i++)
	{
		temp[i] += temp[i - 1];
	}

	for (auto i = 0; i < a.size(); i++)
	{
		temp1[temp[a[i]] - 1] = a[i];
		--temp[a[i]];
	}

	for (auto i = 0; i < a.size(); i++)
	{
		a[i] = temp[i];
	}

}