#include "booklet_print.h"
#include <iostream>

int main(){
  std::cout << "testing 12 pages" << std::endl;
  bookletPrint(1, 12);
  std::cout << "testing 20 pages" << std::endl;
  bookletPrint(1, 20);
}
