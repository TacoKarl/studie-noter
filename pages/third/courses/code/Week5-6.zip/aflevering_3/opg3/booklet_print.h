void bookletPrint(int, int);
