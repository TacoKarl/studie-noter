#include "booklet_print.h"
#include <iostream>

void bookletPrint(int startPage, int endPage) {

  if (startPage > endPage) {
    return;
  }
  int sheet_num = (startPage / 2) + 1;

  std::cout << "Sheet " << sheet_num << " contains: " << startPage
            << ", " << startPage + 1 << ", " << endPage - 1 << ", " << endPage
            << std::endl;

  bookletPrint(startPage + 2, endPage - 2);
}
